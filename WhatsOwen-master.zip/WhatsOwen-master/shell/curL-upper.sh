sudo apt update && sudo apt upgrade
sudo apt install curl
apt-cache search libcurl | grep python
sudo apt install python3-pycurl
